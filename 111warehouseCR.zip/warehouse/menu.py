import os

def print_menu():
    print("-" * 30)
    print("warehouse control system")
    print("-" * 30)

    print('[1] Register new Items')
    print('[2] Display Catalog')
    print('[3] Manual Stock Update')
    print('[4] Remove Item from Catalog')
    print('[5] Calulate total Stock Value')
    print('[6] Register Sale')
    print('[7] View Log')
    print('[X] Close')

def print_header(title):
    clear()
    print('-' * 100)
    print('-------------Item ----------      Description -------- Stock -------- Price')
    print('-' * 100)

def clear():
    return os.system('cls' if os.name =='nt' else 'clear')