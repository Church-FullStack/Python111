
from menu import clear, print_menu, print_header
from item import Item
import pickle
import datetime


catalog = []
log = []
last_id = 0
data_file = 'warehouse.data'
log_file = 'log.data'

def save_catalog():
    global data_file
    writer = open(data_file, "wb")
    pickle.dump(catalog, writer)
    writer.close()
    print("file saved")

def read_catalog():
    global data_file
    try:
        reader = open(data_file, "rb")
        temp_list = pickle.load(reader)
        
        for item in temp_list:
            catalog.append(item)

        print("Data loaded" + str(len(catalog)))
    except:
        print("data load failure")

def save_log():
    global log_file
    writer = open(log_file, "wb")
    pickle.dump(log, writer)
    writer.close()
    print("Log file saved")

def read_log():
    try:
        global log_file
        reader = open(log_file, "rb")
        temp_list = pickle.load(reader)

        for entry in temp_list:
            log.append(entry)
        how_many = len(log)
        print("Loaded" + str(how_many) + "log entries")
    except:
        print("error loading log entries")

def get_current_time():
    now = datetime.datetime.now()
    return now.strftime("%b/%d/%Y %T")
        

def add_log_event(event_type, event_description):
    entry = get_current_time() + " | " + event_type.ljust(10) + " | " + event_description
    log.append(entry)
    save_log()

def print_log():
    global log_file
    reader = open(log_file, "rb")
    temp_list = pickle.load(reader)

    for entry in temp_list:
        log.append(entry)
        print(log)


def register_item():
    print_header("Register New Item")
    try:
        title = input("Item Title: ")
        cat = input("Item Category: ")
        price = float(input("Item Price: "))
        stock = int(input("Item Quantity: "))

        
        last = catalog[-1]
        id = last.id + 1
        new_item = Item(id, title, cat, price, stock)
        catalog.append(new_item)
        add_log_event("NewItem", "Added" + str(last_id))


        print("Item created")
    except ValueError:
        print("Verify values and try again")
    except:
        print("error")

def display_catalog():
    print_header("Warehouse Catalog")

    for item in catalog:
        print(str(item.id).rjust(2)
         + " | " + item.title.ljust(25) 
         + " | " + item.category.ljust(10) 
         + " | " + str(item.stock).rjust(15) 
         + " | " + str(item.price).rjust(5) )
        print('-' * 100)

def update_stock(opc):
    display_catalog()
    id = int(input("Please Select an ID: "))

    found = False
    for item in catalog:
        if(item.id == id):
            found = True

            if(opc == 1):
                stock = int(input("New Stock value: "))
                item.stock = stock
                print("stock updated!")
                add_log_event("SetStock", "UpdatedValue" + str(last_id))

            else:
                sold = int(input("Number of items to sell: "))
                item.stock -= sold
                print("Sale registered")
                add_log_event("RegisteredSale","Sold" + str(sold) + "items of item" + str(last_id))
    if(found != True):
        print("Error: ID not found. ")

def cal_stock_val():
    total = 0.0
    for item in catalog:
        total += (item.price * item.stock)
    print("Total Stock Value: $" + str(total))


def remove_item():
    display_catalog()
    id = int(input("Select Item ID you wish to remove: "))
    found = False
    for item in catalog:
        if(item.id == id):
            catalog.remove(item)
            found = True
            break
    if(found):
        print("Item removed.")
        add_log_event("RemovedItem", "Removed Item: " + str(last_id))
    else:
        print("Error, ID not found.")
            

read_catalog()
read_log()
input("Press enter to begin")

opc = ''
while(opc != 'x'):
    clear()
    print_menu()

    opc = input("please select an option: ")

    if(opc == '1'):
        register_item()
        save_catalog()
    elif(opc == '2'):
        display_catalog()
    elif(opc == '3'):
        update_stock(1)
        save_catalog()
    elif(opc == '4'):
        remove_item()
    elif(opc == '5'):
        cal_stock_val()
    elif(opc == '6'):
        update_stock(2)
        save_catalog()
    elif(opc == '7'):
        print_log()
        
    input("press Enter to continue")
