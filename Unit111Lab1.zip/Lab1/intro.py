print("Hello Python!")

name = "Frank"
age = 34
found = True
average = 123.45

print(name, age, found, average)

print(age - 10, 100 / 3)

if(age < 80):
    print("you are still a young man")
elif(age == 80):
    print("you bouta be dead")
else:
    print("You are aging")