def separator():
    print("--" * 30)


def print_menu():
    separator()
    print("Welcome to PyCalc")
    separator()

    print("[1] - Add")
    print("[2] - Subtract")
    print("[3] - Multiply")
    print("[4] - Divide")

    print("[x] - Quit")
    separator()

def sum(num1, num2):
    return num1 + num2

def subtract(num1, num2):
    return num1 - num2

def mult(num1, num2):
    return num1 * num2

def div(num1, num2):
    return num1 / num2

val = ''
while(val != 'x'):
    print_menu()
    val = input("Please choose an option: ")
    
    if val == '1':
        num1 = int(input("please select first number"))
        num2 = int(input("please select second number"))
        res = sum(num1, num2)
        print("Result: " + str(res))
    
    elif val == '2':
        num1 = int(input("please select first number"))
        num2 = int(input("please select second number"))
        res = subtract(num1, num2)
        print("Result: " + str(res))

    elif val == '3':
        num1 = int(input("please select first number"))
        num2 = int(input("please select second number"))
        res = mult(num1, num2)
        print("Result: " + str(res))
    elif val == '4':
        num1 = int(input("please select first number"))
        num2 = int(input("please select second number"))
        res = div(num1, num2)
        print("Result: " + str(res))
    input("Press enter to continue")
    print("\n" * 4)